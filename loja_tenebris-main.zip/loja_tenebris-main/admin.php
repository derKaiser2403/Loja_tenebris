<?php

include 'conexao.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['atualizar_estoque'])) {
    $produto_id = (int)$_POST['produto_id'];
    $estoque = (int)$_POST['estoque'];

    if ($estoque < 0) {
        $estoque = 0;
    }

    $stmt = $conn->prepare("UPDATE produtos SET estoque = ? WHERE id = ?");
    $stmt->bind_param("ii", $estoque, $produto_id);
    $stmt->execute();

    header("Location: admin.php");
    exit;
}

if (isset($_POST['novo_produto'])) {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = (float)$_POST['preco'];
    $imagem = $_POST['imagem'];
    $categoria = $_POST['categoria'];
    $estoque = (int)$_POST['estoque'];

    $stmt = $conn->prepare("
        INSERT INTO produtos
        (nome, descricao, preco, imagem, categoria, estoque)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "ssdssi",
        $nome,
        $descricao,
        $preco,
        $imagem,
        $categoria,
        $estoque
    );

    $stmt->execute();

    header("Location: admin.php");
    exit;
}

$produtos = $conn->query("
    SELECT *
    FROM produtos
    ORDER BY id DESC
");

$pedidos = $conn->query("
    SELECT 
        p.*,
        u.nome AS cliente_nome
    FROM pedidos p
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    ORDER BY p.id DESC
");

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin - Tenebris</title>

<link rel="stylesheet" href="style.css">

<style>

.admin-container {
    width: 95%;
    max-width: 1100px;
    margin: 30px auto;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.admin-header h1 {
    font-size: 2rem;
}

.admin-header a {
    background: #111;
    color: white;
    padding: 10px 16px;
    border-radius: 8px;
}

.admin-section {
    background: white;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 3px 12px rgba(0,0,0,.06);
}

.admin-section h2 {
    margin-bottom: 18px;
    color: #111;
}

.admin-form {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.admin-form textarea {
    grid-column: span 2;
}

.admin-form input,
.admin-form textarea,
.admin-form select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 7px;
    color: #222;
    background: white;
}

.admin-form button {
    grid-column: span 2;
    padding: 11px;
    border: none;
    border-radius: 7px;
    background: #111;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.admin-form button:hover {
    background: #333;
}

.estoque-lista {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 15px;
}

.produto-admin {
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 15px;
    background: #fafafa;
}

.produto-admin h3 {
    color: #111;
    margin-bottom: 8px;
}

.produto-admin p {
    color: #666;
    margin-bottom: 12px;
}

.estoque-form {
    display: flex;
    gap: 8px;
}

.estoque-form input {
    width: 80px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 6px;
}

.estoque-form button {
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    background: #111;
    color: white;
    cursor: pointer;
}

.estoque-zero {
    color: #c00 !important;
    font-weight: bold;
}

.pedidos-table {
    width: 100%;
    border-collapse: collapse;
}

.pedidos-table th,
.pedidos-table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
    color: #222;
}

.pedidos-table th {
    background: #f3f3f3;
}

@media(max-width:700px) {

    .admin-form {
        grid-template-columns: 1fr;
    }

    .admin-form textarea,
    .admin-form button {
        grid-column: span 1;
    }

    .pedidos-table {
        font-size: .85rem;
    }

}

</style>

</head>

<body>

<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

<a href="logout_admin.php">
    Sair
</a>

</div>


</header>

<div class="admin-container">

    <div class="admin-header">

        <h1>Painel Administrativo</h1>

        <a href="index.php">Voltar à loja</a>

    </div>

    <div class="admin-section">

        <h2>Novo Produto</h2>

        <form method="POST" class="admin-form">

            <input
                type="text"
                name="nome"
                placeholder="Nome do produto"
                required
            >

            <input
                type="text"
                name="categoria"
                placeholder="Categoria"
                required
            >

            <textarea
                name="descricao"
                placeholder="Descrição"
                rows="3"
                required
            ></textarea>

            <input
                type="number"
                name="preco"
                step="0.01"
                min="0"
                placeholder="Preço"
                required
            >

            <input
                type="number"
                name="estoque"
                min="0"
                placeholder="Estoque"
                required
            >

            <input
                type="text"
                name="imagem"
                placeholder="Caminho da imagem"
                required
            >

            <button type="submit" name="novo_produto">
                Cadastrar Produto
            </button>

        </form>

    </div>

    <div class="admin-section">

        <h2>Estoque</h2>

        <div class="estoque-lista">

            <?php while ($produto = $produtos->fetch_assoc()): ?>

                <div class="produto-admin">

                    <h3>
                        <?= htmlspecialchars($produto['nome']); ?>
                    </h3>

                    <?php if ((int)$produto['estoque'] <= 0): ?>

                        <p class="estoque-zero">
                            Estoque esgotado
                        </p>

                    <?php else: ?>

                        <p>
                            Estoque atual:
                            <strong>
                                <?= (int)$produto['estoque']; ?>
                            </strong>
                        </p>

                    <?php endif; ?>

                    <form method="POST" class="estoque-form">

                        <input
                            type="hidden"
                            name="produto_id"
                            value="<?= (int)$produto['id']; ?>"
                        >

                        <input
                            type="number"
                            name="estoque"
                            min="0"
                            value="<?= (int)$produto['estoque']; ?>"
                            required
                        >

                        <button
                            type="submit"
                            name="atualizar_estoque"
                        >
                            Salvar
                        </button>

                    </form>

                </div>

            <?php endwhile; ?>

        </div>

    </div>

    <div class="admin-section">

        <h2>Pedidos</h2>

        <div style="overflow-x:auto;">

            <table class="pedidos-table">

                <thead>

                    <tr>
                        <th>Pedido</th>
                        <th>Cliente</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>

                </thead>

                <tbody>

                    <?php while ($pedido = $pedidos->fetch_assoc()): ?>

                        <tr>

                            <td>
                                #<?= (int)$pedido['id']; ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($pedido['cliente_nome'] ?? 'Cliente'); ?>
                            </td>

                            <td>
                                R$
                                <?= number_format(
                                    $pedido['total'],
                                    2,
                                    ',',
                                    '.'
                                ); ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($pedido['status']); ?>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>

</html>
