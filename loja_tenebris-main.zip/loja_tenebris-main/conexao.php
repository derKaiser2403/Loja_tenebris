<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loja_tenebris";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}
?>