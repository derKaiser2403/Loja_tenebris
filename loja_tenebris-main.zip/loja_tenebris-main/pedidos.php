<?php

include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$id = (int) $_SESSION['usuario_id'];

/* BUSCAR PEDIDOS DO USUÁRIO */
$stmt = $conn->prepare("
    SELECT *
    FROM pedidos
    WHERE usuario_id = ?
    ORDER BY id DESC
");

$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Meus Pedidos - Tenebris</title>

<link
    href="https://fonts.googleapis.com/css2?family=UnifrakturCook:wght@700&family=Roboto:wght@300;400;700&display=swap"
    rel="stylesheet"
>

<link rel="stylesheet" href="style.css">

<style>


.pedidos-container {

    width: 90%;

    max-width: 900px;

    margin: 50px auto;

}


.pedidos-container > h1 {

    text-align: center;

    color: #111;

    margin-bottom: 35px;

    font-size: 2.2rem;

}


.pedido-card {

    background: #fff;

    border: 1px solid #ddd;

    border-radius: 16px;

    padding: 25px;

    margin-bottom: 20px;

    box-shadow:
        0 4px 15px rgba(0, 0, 0, .07);

    transition: .3s;

}

.pedido-card:hover {

    transform: translateY(-3px);

    box-shadow:
        0 8px 22px rgba(0, 0, 0, .12);

}


.pedido-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-bottom: 20px;

    padding-bottom: 15px;

    border-bottom: 1px solid #eee;

}

.pedido-header h3 {

    margin: 0;

    color: #111;

    font-size: 1.25rem;

}

.status {

    display: inline-block;

    padding: 6px 12px;

    border-radius: 20px;

    background: #f1f1f1;

    color: #333;

    font-size: .85rem;

    font-weight: bold;

    text-transform: capitalize;

}


.status.entregue {

    background: #e8f7ed;

    color: #197238;

}

.status.pendente {

    background: #fff5df;

    color: #956000;

}

.status.enviado {

    background: #e8f1ff;

    color: #1859a5;

}


.pedido-info {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;

}

.info-box {

    background: #f7f7f7;

    border: 1px solid #e5e5e5;

    border-radius: 10px;

    padding: 14px 16px;

}

.info-box strong {

    display: block;

    color: #555;

    font-size: .85rem;

    margin-bottom: 5px;

    text-transform: uppercase;

    letter-spacing: .4px;

}

.info-box span {

    color: #111;

    font-size: 1.05rem;

}


.pedido-acoes {

    margin-top: 20px;

    padding-top: 15px;

    border-top: 1px solid #eee;

}


.btn {

    display: inline-block;

    background: #111;

    color: #fff;

    text-decoration: none;

    padding: 11px 18px;

    border-radius: 9px;

    font-weight: bold;

    transition: .3s;

}

.btn:hover {

    background: #333;

    transform: translateY(-2px);

    box-shadow:
        0 5px 15px rgba(0, 0, 0, .18);

}

.pedido-entregue {

    color: #197238;

    font-weight: bold;

    font-size: .95rem;

}


.sem-pedidos {

    text-align: center;

    background: #fff;

    border: 1px solid #ddd;

    padding: 50px 30px;

    border-radius: 16px;

    box-shadow:
        0 4px 15px rgba(0, 0, 0, .07);

}

.sem-pedidos h2 {

    color: #333;

    margin-bottom: 25px;

}


@media (max-width: 650px) {

    .pedidos-container {

        width: 94%;

        margin: 30px auto;

    }

    .pedidos-container > h1 {

        font-size: 1.8rem;

    }

    .pedido-header {

        align-items: flex-start;

        flex-direction: column;

    }

    .pedido-info {

        grid-template-columns: 1fr;

    }

    .btn {

        width: 100%;

        text-align: center;

    }

}

</style>

</head>

<body>


<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

        <a
            href="index.php"
            class="btn-voltar"
        >
            ← Voltar para a loja
        </a>

    </div>

</header>


<main class="pedidos-container">


    <h1>
        📦 Meus Pedidos
    </h1>


    <?php if ($result->num_rows > 0): ?>


        <?php while ($pedido = $result->fetch_assoc()): ?>

            <?php

            $status = strtolower(trim($pedido['status']));

            ?>


            <div class="pedido-card">


                <div class="pedido-header">

                    <h3>
                        Pedido #<?= (int) $pedido['id']; ?>
                    </h3>


                    <span class="status <?= htmlspecialchars($status); ?>">

                        <?= htmlspecialchars($pedido['status']); ?>

                    </span>

                </div>


                <div class="pedido-info">


                    <div class="info-box">

                        <strong>
                            Número do pedido
                        </strong>

                        <span>
                            #<?= (int) $pedido['id']; ?>
                        </span>

                    </div>


                    <div class="info-box">

                        <strong>
                            Total
                        </strong>

                        <span>

                            R$

                            <?= number_format(
                                $pedido['total'],
                                2,
                                ',',
                                '.'
                            ); ?>

                        </span>

                    </div>


                </div>


                <?php if ($status !== 'entregue'): ?>

                    <div class="pedido-acoes">

                        <a
                            href="entregue.php?id=<?= (int) $pedido['id']; ?>"
                            class="btn"
                            onclick="return confirm('Deseja confirmar que este pedido foi entregue?');"
                        >
                            ✓ Confirmar Pedido Entregue
                        </a>

                    </div>

                <?php else: ?>

                    <div class="pedido-acoes">

                        <span class="pedido-entregue">
                            ✓ Pedido entregue
                        </span>

                    </div>

                <?php endif; ?>


            </div>


        <?php endwhile; ?>


    <?php else: ?>


        <div class="sem-pedidos">

            <h2>
                Você ainda não fez nenhum pedido.
            </h2>


            <a
                href="index.php"
                class="btn"
            >
                🛍️ Ir às Compras
            </a>

        </div>


    <?php endif; ?>


</main>

</body>

</html>