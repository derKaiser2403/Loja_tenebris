<?php

include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION['carrinho'])) {
    header("Location: carrinho.php");
    exit;
}

$total = 0;

foreach ($_SESSION['carrinho'] as $item) {
    $total += $item['preco'] * $item['qtd'];
}

$frete = $total >= 299.99 ? 0 : 45;

$total_final = $total + $frete;

$erro = '';

if (isset($_POST['finalizar'])) {

    $usuario_id = (int)$_SESSION['usuario_id'];
    $pagamento = $_POST['pagamento'];

    $conn->begin_transaction();

    try {

        foreach ($_SESSION['carrinho'] as $produto_id => $item) {

            $produto_id = (int)$produto_id;
            $quantidade = (int)$item['qtd'];

            $stmt = $conn->prepare("
                SELECT estoque
                FROM produtos
                WHERE id = ?
                FOR UPDATE
            ");

            $stmt->bind_param("i", $produto_id);
            $stmt->execute();

            $resultado = $stmt->get_result();
            $produto = $resultado->fetch_assoc();

            if (!$produto) {
                throw new Exception(
                    "Produto não encontrado."
                );
            }

            if ((int)$produto['estoque'] < $quantidade) {
                throw new Exception(
                    "O produto " .
                    $item['nome'] .
                    " não possui estoque suficiente."
                );
            }
        }

        $stmt = $conn->prepare("
            INSERT INTO pedidos
            (
                usuario_id,
                total,
                status,
                forma_pagamento
            )
            VALUES
            (?, ?, 'a caminho', ?)
        ");

        $stmt->bind_param(
            "ids",
            $usuario_id,
            $total_final,
            $pagamento
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Não foi possível criar o pedido."
            );
        }

        foreach ($_SESSION['carrinho'] as $produto_id => $item) {

            $produto_id = (int)$produto_id;
            $quantidade = (int)$item['qtd'];

            $stmt = $conn->prepare("
                UPDATE produtos
                SET estoque = estoque - ?
                WHERE id = ?
                AND estoque >= ?
            ");

            $stmt->bind_param(
                "iii",
                $quantidade,
                $produto_id,
                $quantidade
            );

            if (!$stmt->execute() || $stmt->affected_rows !== 1) {
                throw new Exception(
                    "Não foi possível atualizar o estoque."
                );
            }
        }

        $conn->commit();

        $_SESSION['carrinho'] = [];

        header("Location: pedidos.php");
        exit;

    } catch (Exception $e) {

        $conn->rollback();

        $erro = $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Pagamento - Tenebris</title>

<link rel="stylesheet" href="style.css">

<style>

.pagamento-container {
    width: 90%;
    max-width: 700px;
    margin: 40px auto;
}

.pagamento-card {
    background: white;
    color: #111;
    padding: 30px;
    border-radius: 15px;
    border: 1px solid #ddd;
    box-shadow: 0 5px 20px rgba(0,0,0,.08);
}

.pagamento-card h1 {
    margin-bottom: 25px;
}

.resumo {
    background: #f5f5f5;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 25px;
}

.resumo p,
.resumo h2 {
    margin-bottom: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 7px;
    font-weight: bold;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    background: white;
    color: #111;
}

.btn-finalizar {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 8px;
    background: #111;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.btn-finalizar:hover {
    background: #333;
}

.erro {
    background: #ffe5e5;
    color: #b00000;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.voltar {
    display: inline-block;
    margin-bottom: 20px;
    color: #333;
    font-weight: bold;
}

</style>

</head>

<body>

<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

        <a href="index.php">Loja</a>

        <a href="carrinho.php">🛒</a>

        <a href="conta.php">👤</a>

    </div>

</header>

<div class="pagamento-container">

    <a href="carrinho.php" class="voltar">
        ← Voltar ao carrinho
    </a>

    <div class="pagamento-card">

        <h1>Finalizar Compra</h1>

        <?php if ($erro): ?>

            <div class="erro">
                <?= htmlspecialchars($erro); ?>
            </div>

        <?php endif; ?>

        <div class="resumo">

            <p>
                Subtotal:
                R$ <?= number_format(
                    $total,
                    2,
                    ',',
                    '.'
                ); ?>
            </p>

            <p>
                Frete:

                <?php if ($frete == 0): ?>

                    GRÁTIS

                <?php else: ?>

                    R$ <?= number_format(
                        $frete,
                        2,
                        ',',
                        '.'
                    ); ?>

                <?php endif; ?>

            </p>

            <h2>
                Total:
                R$ <?= number_format(
                    $total_final,
                    2,
                    ',',
                    '.'
                ); ?>
            </h2>

        </div>

        <form method="POST">

            <div class="form-group">

                <label>
                    Nome Completo
                </label>

                <input
                    type="text"
                    name="nome"
                    required
                >

            </div>

            <div class="form-group">

                <label>
                    Endereço
                </label>

                <input
                    type="text"
                    name="endereco"
                    required
                >

            </div>

            <div class="form-group">

                <label>
                    Forma de Pagamento
                </label>

                <select
                    name="pagamento"
                    required
                >

                    <option value="Pix">
                        Pix
                    </option>

                    <option value="Cartão de Crédito">
                        Cartão de Crédito
                    </option>

                    <option value="Cartão de Débito">
                        Cartão de Débito
                    </option>

                    <option value="Boleto">
                        Boleto
                    </option>

                </select>

            </div>

            <div class="form-group">

                <label>
                    Parcelamento
                </label>

                <select name="parcelas">

                    <option value="1">
                        1x de R$
                        <?= number_format(
                            $total_final,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                    <option value="2">
                        2x de R$
                        <?= number_format(
                            $total_final / 2,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                    <option value="3">
                        3x de R$
                        <?= number_format(
                            $total_final / 3,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                    <option value="4">
                        4x de R$
                        <?= number_format(
                            $total_final / 4,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                    <option value="5">
                        5x de R$
                        <?= number_format(
                            $total_final / 5,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                    <option value="6">
                        6x de R$
                        <?= number_format(
                            $total_final / 6,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </option>

                </select>

            </div>

            <button
                type="submit"
                name="finalizar"
                class="btn-finalizar"
            >
                Finalizar Compra
            </button>

        </form>

    </div>

</div>

</body>

</html>
