<?php
include 'conexao.php';

$msg = '';
$desconto = 0;

if (isset($_GET['add'])) {

    $id = (int)$_GET['add'];

    $produto = $conn->query(
        "SELECT * FROM produtos WHERE id = $id"
    )->fetch_assoc();

    if ($produto) {

        if (isset($_SESSION['carrinho'][$id])) {

            $_SESSION['carrinho'][$id]['qtd']++;

        } else {

            $_SESSION['carrinho'][$id] = [
                'id' => $produto['id'],
                'nome' => $produto['nome'],
                'preco' => $produto['preco'],
                'imagem' => $produto['imagem'],
                'qtd' => 1
            ];
        }

        header("Location: carrinho.php");
        exit;
    }
}

$cat = isset($_GET['cat']) ? $_GET['cat'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($cat) {
    $sql = "SELECT * FROM produtos WHERE categoria = '$cat'";
} elseif ($search) {
    $sql = "SELECT * FROM produtos
            WHERE nome LIKE '%$search%'
            OR descricao LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM produtos";
}

$result = $conn->query($sql);

$cat = isset($_GET['cat']) ? $_GET['cat'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($cat) {
    $sql = "SELECT * FROM produtos WHERE categoria = '$cat'";
} elseif ($search) {
    $sql = "SELECT * FROM produtos
            WHERE nome LIKE '%$search%'
            OR descricao LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM produtos";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>O Estranho Mundo de Tenebris</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

<?php if(isset($_SESSION['admin_id'])): ?>

    <a href="admin.php">
        ⚙️ Painel
    </a>

    <a href="logout_admin.php">
        Sair
    </a>

<?php elseif(isset($_SESSION['usuario_id'])): ?>

    <a href="conta.php">
        👤 <?= htmlspecialchars($_SESSION['usuario_nome']); ?>
    </a>

    <a href="carrinho.php">
        🛒
    </a>

<?php else: ?>

    <a href="login.php">
        👤
    </a>

    <a href="carrinho.php">
        🛒
    </a>

<?php endif; ?>

</div>


</header>

<div class="banner">
    <img src="img/banner/banner.jpg" alt="Banner Tenebris">
</div>

<div class="container">

    <div class="filters">
        <form method="GET" action="index.php" class="search-form">
            <input type="text" name="search" placeholder="Buscar artefatos...">
            <button type="submit">🔍</button>
        </form>
        
        <div class="categorias">
            <a href="index.php">Todos</a>
            <a href="index.php?cat=blusa">Blusas</a>
            <a href="index.php?cat=sapato">Sapatos</a>
            <a href="index.php?cat=calca">Calças</a>
            <a href="index.php?cat=acessorio">Acessórios</a>
        </div>
    </div>

    <div class="product-grid">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='product-card'>";
                echo "<img src='".$row['imagem']."' width='200'>";
                echo "<h3>".$row['nome']."</h3>";
                echo "<p>".$row['descricao']."</p>";
                echo "<p class='price'>R$ ".number_format($row['preco'], 2, ',', '.')."</p>";
                echo "<a href='index.php?add=".$row['id']."' class='btn-buy'>Adicionar ao Carrinho</a>";
                echo "</div>";
            }
        }
        ?>
    </div>
</div>

<footer>
    <p>© 2026 O Estranho Mundo de Tenebris</p>
</footer>

</body>
</html>