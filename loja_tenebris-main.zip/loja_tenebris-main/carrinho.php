<?php
include 'conexao.php';

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

/* REMOVER PRODUTO */
if (isset($_GET['remover'])) {

    $id = (int) $_GET['remover'];

    unset($_SESSION['carrinho'][$id]);

    header("Location: carrinho.php");
    exit;
}

/* ATUALIZAR QUANTIDADES */
if (isset($_POST['atualizar'])) {

    if (isset($_POST['qtd']) && is_array($_POST['qtd'])) {

        foreach ($_POST['qtd'] as $id => $qtd) {

            $id = (int) $id;
            $qtd = (int) $qtd;

            if ($qtd > 0 && isset($_SESSION['carrinho'][$id])) {

                $_SESSION['carrinho'][$id]['qtd'] = $qtd;

            } else {

                unset($_SESSION['carrinho'][$id]);

            }
        }
    }

    header("Location: carrinho.php");
    exit;
}

/* CALCULAR TOTAL */
$total = 0;

foreach ($_SESSION['carrinho'] as $item) {

    $total += $item['preco'] * $item['qtd'];

}

/* FRETE */
if ($total >= 299.99) {

    $frete = 0;

} else {

    $frete = 45;

}

$total_final = $total + $frete;

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Carrinho - Tenebris</title>

<link rel="stylesheet" href="style.css">

<style>


.carrinho-container {
    width: 90%;
    max-width: 1200px;
    margin: 50px auto;
}

.carrinho-container > h1 {
    text-align: center;
    color: #111;
    margin-bottom: 35px;
    font-size: 2.2rem;
}

.carrinho-item {
    display: flex;
    align-items: center;
    gap: 25px;

    background: #fff;

    border: 1px solid #ddd;
    border-radius: 15px;

    padding: 20px;
    margin-bottom: 20px;

    box-shadow: 0 3px 12px rgba(0, 0, 0, .06);

    transition: .3s;
}

.carrinho-item:hover {
    transform: translateY(-3px);

    box-shadow:
        0 8px 20px rgba(0, 0, 0, .12);
}

.carrinho-item img {
    width: 120px;
    height: 120px;

    object-fit: cover;

    border-radius: 10px;

    border: 1px solid #ddd;
}

.info {
    flex: 1;
}

.info h3 {
    margin-bottom: 10px;

    color: #111;

    font-size: 1.2rem;
}

.info p {
    color: #666;

    margin-bottom: 8px;
}

.info input {
    width: 75px;

    padding: 9px;

    border-radius: 8px;

    border: 1px solid #ccc;

    background: #f8f8f8;

    color: #111;

    font-size: 1rem;

    outline: none;
}

.info input:focus {
    border-color: #555;

    box-shadow:
        0 0 5px rgba(0, 0, 0, .12);
}

.remover {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 40px;
    height: 40px;

    border-radius: 50%;

    color: #d00000;

    font-size: 1.2rem;

    transition: .3s;
}

.remover:hover {
    background: #ffe5e5;

    transform: scale(1.1);
}

.total {
    background: #fff;

    border: 1px solid #ddd;

    border-radius: 15px;

    padding: 25px;

    margin-top: 30px;

    text-align: right;

    box-shadow:
        0 3px 12px rgba(0, 0, 0, .06);
}

.total p {
    color: #555;

    margin-bottom: 10px;

    font-size: 1.05rem;
}

.total h2 {
    color: #111;

    margin-top: 15px;

    font-size: 1.7rem;
}


.success {
    margin-top: 20px;

    padding: 15px;

    background: #e9f8ee;

    border: 1px solid #b8e6c5;

    color: #176b2c;

    border-radius: 10px;

    text-align: center;

    font-weight: bold;
}

.carrinho-container > p:not(.success) {
    margin-top: 20px;

    padding: 15px;

    background: #fff;

    border: 1px solid #ddd;

    border-radius: 10px;

    color: #555;

    text-align: center;
}

.acoes {
    display: flex;

    gap: 15px;

    margin-top: 25px;

    flex-wrap: wrap;
}

.btn {
    display: inline-block;

    padding: 13px 25px;

    background: #111;

    color: #fff;

    border: none;

    border-radius: 10px;

    cursor: pointer;

    font-weight: bold;

    font-size: .95rem;

    transition: .3s;
}

.btn:hover {
    background: #333;

    box-shadow:
        0 5px 15px rgba(0, 0, 0, .18);

    transform: translateY(-2px);
}

.carrinho-vazio {
    background: #fff;

    border: 1px solid #ddd;

    border-radius: 15px;

    padding: 50px 20px;

    text-align: center;

    box-shadow:
        0 3px 12px rgba(0, 0, 0, .06);
}

.carrinho-vazio h2 {
    color: #333;

    margin-bottom: 25px;
}


@media (max-width: 768px) {

    .carrinho-container {
        width: 94%;
        margin: 30px auto;
    }

    .carrinho-item {
        gap: 15px;

        padding: 15px;
    }

    .carrinho-item img {
        width: 90px;
        height: 90px;
    }

    .info h3 {
        font-size: 1rem;
    }

    .info p {
        font-size: .9rem;
    }

    .total {
        text-align: left;
    }

    .acoes {
        flex-direction: column;
    }

    .acoes .btn {
        width: 100%;

        text-align: center;
    }
}

</style>

</head>

<body>

<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

        <a
            href="index.php"
            class="btn-voltar"
        >
            ← Voltar para a loja
        </a>

    </div>

</header>


<div class="carrinho-container">

    <h1>Seu Carrinho</h1>


    <?php if (!empty($_SESSION['carrinho'])): ?>

        <form method="POST">

            <?php foreach ($_SESSION['carrinho'] as $id => $item): ?>

                <?php

                $subtotal = $item['preco'] * $item['qtd'];

                ?>

                <div class="carrinho-item">

                    <img
                        src="<?= htmlspecialchars($item['imagem']); ?>"
                        alt="<?= htmlspecialchars($item['nome']); ?>"
                    >


                    <div class="info">

                        <h3>
                            <?= htmlspecialchars($item['nome']); ?>
                        </h3>


                        <p>
                            Preço:

                            <strong>
                                R$
                                <?= number_format(
                                    $item['preco'],
                                    2,
                                    ',',
                                    '.'
                                ); ?>
                            </strong>
                        </p>


                        <p>
                            Subtotal:

                            <strong>
                                R$
                                <?= number_format(
                                    $subtotal,
                                    2,
                                    ',',
                                    '.'
                                ); ?>
                            </strong>
                        </p>


                        <label>
                            Quantidade:

                            <input
                                type="number"
                                min="1"
                                name="qtd[<?= $id ?>]"
                                value="<?= (int)$item['qtd']; ?>"
                            >

                        </label>

                    </div>


                    <a
                        class="remover"
                        href="carrinho.php?remover=<?= $id ?>"
                        title="Remover produto"
                        onclick="return confirm('Deseja remover este produto do carrinho?');"
                    >
                        ❌
                    </a>

                </div>

            <?php endforeach; ?>


            <div class="total">

                <p>
                    Subtotal:

                    R$
                    <?= number_format(
                        $total,
                        2,
                        ',',
                        '.'
                    ); ?>
                </p>


                <p>

                    Frete:

                    <?php if ($frete == 0): ?>

                        <strong style="color:#176b2c;">
                            GRÁTIS
                        </strong>

                    <?php else: ?>

                        R$
                        <?= number_format(
                            $frete,
                            2,
                            ',',
                            '.'
                        ); ?>

                    <?php endif; ?>

                </p>


                <h2>

                    Total:

                    R$
                    <?= number_format(
                        $total_final,
                        2,
                        ',',
                        '.'
                    ); ?>

                </h2>

            </div>


            <?php if ($frete == 0): ?>

                <p class="success">
                    🎉 Você ganhou frete grátis!
                </p>

            <?php else: ?>

                <p>

                    Faltam

                    <strong>
                        R$
                        <?= number_format(
                            299.99 - $total,
                            2,
                            ',',
                            '.'
                        ); ?>
                    </strong>

                    para ganhar frete grátis.

                </p>

            <?php endif; ?>


            <div class="acoes">

                <button
                    type="submit"
                    class="btn"
                    name="atualizar"
                >
                    Atualizar Carrinho
                </button>


                <a
                    class="btn"
                    href="index.php"
                >
                    Continuar Comprando
                </a>


                <a
                    class="btn"
                    href="pagamento.php"
                >
                    Finalizar Compra
                </a>

            </div>

        </form>


    <?php else: ?>


        <div class="carrinho-vazio">

            <h2>
                🛒 Seu carrinho está vazio
            </h2>

            <a
                class="btn"
                href="index.php"
            >
                Voltar à Loja
            </a>

        </div>


    <?php endif; ?>

</div>

</body>

</html>