<?php

include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$id = (int) $_SESSION['usuario_id'];

/* BUSCAR USUÁRIO COM SEGURANÇA */
$stmt = $conn->prepare(
    "SELECT * FROM usuarios WHERE id = ?"
);

$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();

if (!$user) {
    session_destroy();

    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Minha Conta - Tenebris</title>

<link
    href="https://fonts.googleapis.com/css2?family=UnifrakturCook:wght@700&family=Roboto:wght@300;400;700&display=swap"
    rel="stylesheet"
>

<link rel="stylesheet" href="style.css">

<style>

.conta-container {

    width: 90%;

    max-width: 850px;

    margin: 50px auto;

}


.conta-card {

    background: #fff;

    border: 1px solid #ddd;

    border-radius: 18px;

    padding: 35px;

    box-shadow:
        0 5px 20px rgba(0, 0, 0, .08);

}

.conta-card h1 {

    text-align: center;

    color: #111;

    font-size: 2rem;

    margin-bottom: 35px;

}


.conta-avatar {

    width: 85px;

    height: 85px;

    margin: 0 auto 20px;

    border-radius: 50%;

    background: #111;

    color: #fff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 2.2rem;

}


.conta-info {

    display: flex;

    flex-direction: column;

    gap: 6px;

    background: #f7f7f7;

    border: 1px solid #e2e2e2;

    padding: 16px 18px;

    border-radius: 10px;

    margin-bottom: 15px;

    color: #333;

}

.conta-info strong {

    color: #111;

    font-size: .9rem;

    text-transform: uppercase;

    letter-spacing: .5px;

}

.conta-info span {

    color: #555;

    font-size: 1rem;

    word-break: break-word;

}


.conta-acoes {

    display: flex;

    gap: 15px;

    margin-top: 30px;

    flex-wrap: wrap;

}


.btn-tenebris {

    flex: 1;

    min-width: 180px;

    display: inline-block;

    padding: 13px 20px;

    background: #111;

    color: #fff;

    border-radius: 10px;

    text-decoration: none;

    font-weight: bold;

    text-align: center;

    transition: .3s;

}

.btn-tenebris:hover {

    background: #333;

    transform: translateY(-2px);

    box-shadow:
        0 6px 15px rgba(0, 0, 0, .18);

}


.btn-sair {

    background: #fff;

    color: #b00000;

    border: 1px solid #e0b0b0;

}

.btn-sair:hover {

    background: #fff3f3;

    color: #900;

    box-shadow:
        0 6px 15px rgba(150, 0, 0, .12);

}


footer {

    margin-top: 60px;

    text-align: center;

    padding: 30px;

    border-top: 1px solid #ddd;

    background: #fff;

    color: #777;

}

@media (max-width: 600px) {

    .conta-container {

        width: 94%;

        margin: 30px auto;

    }

    .conta-card {

        padding: 25px 20px;

    }

    .conta-card h1 {

        font-size: 1.7rem;

    }

    .conta-acoes {

        flex-direction: column;

    }

    .btn-tenebris {

        width: 100%;

    }

}

</style>

</head>

<body>


<header>

    <div class="header-top">

        <a href="index.php" class="logo">
            O Estranho Mundo de Tenebris
        </a>

    </div>

    <div class="menu-links">

        <a
            href="index.php"
            class="btn-voltar"
        >
            ← Voltar para a loja
        </a>

    </div>

</header>


<main class="conta-container">

    <div class="conta-card">


        <div class="conta-avatar">
            👤
        </div>


        <h1>
            Minha Conta
        </h1>


        <div class="conta-info">

            <strong>
                Nome
            </strong>

            <span>
                <?= htmlspecialchars($user['nome']); ?>
            </span>

        </div>


        <div class="conta-info">

            <strong>
                Email
            </strong>

            <span>
                <?= htmlspecialchars($user['email']); ?>
            </span>

        </div>


        <div class="conta-info">

            <strong>
                CPF
            </strong>

            <span>
                <?= htmlspecialchars($user['cpf']); ?>
            </span>

        </div>


        <div class="conta-acoes">

            <a
                href="pedidos.php"
                class="btn-tenebris"
            >
                📦 Meus Pedidos
            </a>


            <a
                href="logout.php"
                class="btn-tenebris btn-sair"
            >
                🚪 Sair
            </a>

        </div>


    </div>

</main>


<footer>

    <p>
        © 2026 O Estranho Mundo de Tenebris
    </p>

</footer>


</body>

</html>