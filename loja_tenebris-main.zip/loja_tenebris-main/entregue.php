<?php
include 'conexao.php';

$id = (int)$_GET['id'];

$conn->query("
UPDATE pedidos
SET status = 'entregue'
WHERE id = $id
");

header("Location: pedidos.php");
exit;